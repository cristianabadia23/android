package com.example.a3enraya.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.example.a3enraya.R;
import com.example.a3enraya.models.Partida;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;

public class EncontrarPartidaActivity extends AppCompatActivity {
    ProgressBar progressBar;
    TextView textView;
    Button jugar,ranking;
    String uid,jugada;
    //firebase
    FirebaseAuth auth;
    FirebaseFirestore db;
    FirebaseUser user;
    ListenerRegistration listener = null;
    //lottie
    LottieAnimationView animation,animation2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encontrar_partida);
        this.progressBar = findViewById(R.id.progressBar2);
        this.textView = findViewById(R.id.textView);
        this.jugar = findViewById(R.id.jugar);
        this.ranking = findViewById(R.id.ranking);
        this.progressBar.setVisibility(View.GONE);
        this.textView.setVisibility(View.GONE);
        this.animation = findViewById(R.id.animacion);
        this.animation2 = findViewById(R.id.animacionbotones);
        this.animation.setVisibility(View.GONE);
    }
    public void initFireBase(){
        this.auth = FirebaseAuth.getInstance();
        this.db = FirebaseFirestore.getInstance();
        this.user = this.auth.getCurrentUser();
        this.uid = this.user.getUid();
    }
    public void buscarPartida(View v){
        this.mostrar();
        this.textView.setText("BUSCANDO PARTIDA ...");
        this.buscarPartidaIniciada();
    }

    public void mostrarRanking(View v){
        this.mostrar();
        this.textView.setText("CARGANDO RANKING ...");
    }

    public void mostrar(){
        this.progressBar.setVisibility(View.VISIBLE);
        this.progressBar.setIndeterminate(true);
        this.textView.setVisibility(View.VISIBLE);
        this.animation.setVisibility(View.VISIBLE);
        this.jugar.setVisibility(View.GONE);
        this.ranking.setVisibility(View.GONE);
        this.animation2.setVisibility(View.GONE);
    }

    //Firebase
    public void cerrarSesion(View v){
        this.auth.getInstance().signOut();
        Intent i = new Intent(EncontrarPartidaActivity.this,LoginActivity.class);
        startActivity(i);
    }

    public void buscarPartidaIniciada(){
        this.db.collection("jugadas").whereEqualTo("JugadorDos","").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.getResult().size() != 0){
                            DocumentSnapshot DocJ = task.getResult().getDocuments().get(0);
                            jugada = DocJ.getId();
                            Partida partida = DocJ.toObject(Partida.class);
                            partida.setJugador2(jugada);
                            db.collection("jugadas").document("Jugador1")
                                    .set(partida)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Intent i = new Intent(EncontrarPartidaActivity.this,GameActivity.class);
                                            i.putExtra("jugadaID",jugada);
                                            startActivity(i);
                                        }
                                    });
                        }
                        else{
                            Partida p1 = new Partida(uid);
                            db.collection("jugadas").add(p1)
                                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                        @Override
                                        public void onSuccess(DocumentReference documentReference) {
                                            jugada = documentReference.getId();
                                            listener = db.collection("jugadas")
                                                    .document(jugada)
                                                    .addSnapshotListener(new EventListener<DocumentSnapshot>() {
                                                        @Override
                                                        public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                                                            
                                                        }
                                                    })
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

}