package com.example.a3enraya.utilidades;

public class UtilLayout {
}
